# Six Motors Control Panel Web Page Front-End Full stack developing 
*This repository is about creating a control panel web page for controlling six motors by its angles*
**NOTE**
***this work is based on Full Stack Front-End developing***
*Here is the list of files:*
1. index.html 
2. style.css
3. main.js
4. index.php
5. fetch-latest-record.php
6. RECORDING Vd


